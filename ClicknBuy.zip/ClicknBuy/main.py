from flask import Flask,render_template,Response, redirect,url_for,flash,current_app
import base64
from flask import request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import os
import secrets

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:@localhost/click&buy"
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'
db = SQLAlchemy(app)


class Users(db.Model):
    ID = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String(80), unique=False, nullable=False)
    Phone = db.Column(db.String(80), unique=False, nullable=False)
    Email = db.Column(db.String(80), unique=False, nullable=False)
    Password = db.Column(db.String(80), unique=False, nullable=False)
    Address = db.Column(db.String(80), unique=False, nullable=False)


class Products(db.Model):
    ID = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(80), unique=False, nullable=False)
    price = db.Column(db.String(80), unique=False, nullable=False)
    img = db.Column(db.String(120),default = '*.jpg')
    

class cart(db.Model):
    ID = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(80), unique=False, nullable=False)
    price = db.Column(db.String(80), unique=False, nullable=False)
    img = db.Column(db.String(120),default = '*.jpg')
    quantity = db.Column(db.Integer, nullable=False)



def save_images(photo):
    hash_photo = secrets.token_urlsafe(10)
    _, file_extention = os.path.splitext(photo.filename)
    photo_name = hash_photo + file_extention
    file_path = os.path.join(current_app.root_path, 'static/images',photo_name)
    photo.save(file_path)
    return photo_name



@app.route("/")
def home():
    return render_template("index.html")



@app.route("/login", methods = ['GET','POST'])
def login():
    if(request.method == "POST"):
        username = request.form.get("username")
        password = request.form.get("password")
        User = Users.query.filter_by(Email=username).first()
        if username=="admin" and password=="12345":
            return render_template("adminPanel.html" )
        elif username==User.Email and password==User.Password:
            return render_template("userPanel.html",username=User.Name)
        flash("Invalid username or password")
        return render_template("login.html")

    return render_template("login.html")



@app.route("/signUp", methods = ['GET','POST'])
def signUp():
    if(request.method == "POST"):
        Name = request.form.get("name")
        Email = request.form.get("email")
        Phone = request.form.get("number")
        Password = request.form.get("password")
        Address = request.form.get("address")

        entry = Users(Name=Name , Email=Email , Phone=Phone , Password=Password , Address=Address)
        db.session.add(entry)
        db.session.commit()
        return render_template("login.html")
    return render_template("signUp.html")



@app.route("/signUpSuccess")
def signUpSuccess():
    return render_template("signUpSuccess.html")



@app.route("/addProduct")
def addProduct():
    return render_template("addProduct.html")



@app.route("/upload",methods = ['GET','POST'])
def upload():
    if(request.method == "POST"):
        product_name = request.form.get("productname")
        price = request.form.get("price")
        pic = save_images(request.files.get('pic'))
        if not pic:
            return 'No pic uploaded!', 400

        entry = Products(product_name=product_name , price=price ,img=pic)
        db.session.add(entry)
        db.session.commit()
        flash("Product Added !")
        return render_template("addProduct.html")
    return render_template("addProduct.html")



@app.route("/addProductSuccess")
def addProductSuccess():
    image = Products.query.all()
    images = []
    name = []
    price = []
    delid = []
    for i in image:
        images.append(i.img)
        name.append(i.product_name)
        price.append(i.price)
        delid.append(i.ID) 
    return render_template("adminViewProducts.html" , img=images, name=name,price=price, ID=delid)



@app.route('/deleteItem/<string:id>', methods = ['GET']) 
def deleteItem(id):
    Products.query.filter(Products.ID == id).delete()
    db.session.commit()


    image = Products.query.all()
    images = []
    name = []
    price = []
    delid = []
    for i in image:
        images.append(i.img)
        name.append(i.product_name)
        price.append(i.price)
        delid.append(i.ID) 
    return render_template("adminViewProducts.html" , img=images, name=name,price=price, ID=delid)


@app.route("/shoppingPage")
def shoppingPage():
    image = Products.query.all()
    images = []
    name = []
    price = []
    delid = []
    for i in image:
        images.append(i.img)
        name.append(i.product_name)
        price.append(i.price)
        delid.append(i.ID) 
    return render_template("shoppingPage.html" , img=images, name=name,price=price, ID=delid)

@app.route("/addtocart",methods = ['GET','POST'])
def addtocart():
    if(request.method == "POST"):
        product_id = request.form.get("product_id")
        quantity = request.form.get("quantity")
        Product = Products.query.filter_by(ID=product_id).first()

        entrycart = cart(product_name=Product.product_name , price=Product.price ,img=Product.img, quantity=quantity)
        db.session.add(entrycart)
        db.session.commit()

    image = Products.query.all()
    images = []
    name = []
    price = []
    delid = []
    for i in image:
        images.append(i.img)
        name.append(i.product_name)
        price.append(i.price)
        delid.append(i.ID) 
    return render_template("shoppingPage.html" , img=images, name=name,price=price, ID=delid)



@app.route("/openCart")
def openCart():
    total=0
    cart1 = cart.query.all()
    images = []
    name = []
    price = []
    quantity = []
    for i in cart1:
        images.append(i.img)
        name.append(i.product_name)
        price.append(i.price)
        rs = int(i.price)
        total = total + rs
        quantity.append(i.quantity)
    return render_template("openCart.html" , img=images, name=name,price=price, quantity=quantity, total=str(total))


@app.route("/orderplaced")
def orderplaced():
    cart.query.filter().delete()
    db.session.commit()
    return render_template("orderplaced.html")

app.run(debug = True)